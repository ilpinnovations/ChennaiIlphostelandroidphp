<?php 

include('connectioncode.php');

$sql="insert into zrating".$_GET["ratingtable"]." values(null,'".$_GET["name"]."','".$_GET["empid"]."','".$_GET["comment"]."',now(),'".$_GET["rating"]."')";
$result=mysql_query($sql,$con) or die(mysql_error());
echo "sucess";
?>