<?php 

include('connectioncode.php');

$sql="select * from register where imei='".$_GET["imei"]."' ";
echo $sql;
$result=mysql_query($sql,$con);

echo mysql_result($result,0,0)."xyzzyspoonshift".mysql_result($result,0,1)."xyzzyspoonshift".mysql_result($result,0,2)."xyzzyspoonshift".mysql_result($result,0,3)."xyzzyspoonshift".mysql_result($result,0,4)."xyzzyspoonshift".mysql_result($result,0,5);

?>