<?php 
include('connectioncode.php');


$sql="select * from places1";
$result=mysql_query($sql,$con);


while($conn=mysql_fetch_array($result))
{




$sql4="drop table zrating".$conn["ratingtable"]."";
mysql_query($sql4,$con);

}


 ?>