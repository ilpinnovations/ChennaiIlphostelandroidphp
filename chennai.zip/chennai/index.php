<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Chennai Hostel Search</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900|Quicksand:400,700|Questrial" rel="stylesheet" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />

<!--[if IE 6]><link href="default_ie6.css" rel="stylesheet" type="text/css" /><![endif]-->
<style>
input
{
padding:10px;
font-size:20px;
}
</style>
</head>
<body>
<div id="header-wrapper">
	<div id="header" class="container">
		<div id="logo">
			<h1><span class="icon icon-cog"></span><a href="#">Ilp Innovations</a></h1>
			<div id="menu">
				<ul>
					<li class="current_page_item"><a href="#" accesskey="1" title="">Home</a></li>
					<li><a href="manage.php" accesskey="2" title="">Manage Hostels</a></li>
					<li><a href="#" accesskey="3" title="">About Ilp Innovations</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
<div id="page-wrapper">
	<div id="page" class="container">
                <?php if(isset($_GET["data"])) echo "<h2 style='color:green;'>".$_GET["data"]."</h2>"; ?>
		
		<form action="upload.php" method="post" enctype="multipart/form-data">
		<table width="50%" align="center" cellspacing="10">
		<tr><td><input type="text" placeholder="Hostel Name" name="name"></td><td><input type="text" placeholder="Address" name="address"></td></tr>		
		<tr><td><input type="text" placeholder="Longitude" name="lon"></td><td><input type="text" placeholder="Latitude" name="lat"></td></tr>
		<tr><td><input type="text" placeholder="Employee Id" name="employeeid"></td><td><input type="text" placeholder="Employee Name" name="name1"></td></tr>
		<tr><td><input type="text" placeholder="Stream" name="stream"></td><td><input type="text" placeholder="Batch No" name="batch"></td></tr>
		<tr><td><input type="text" placeholder="Location" name="location"></td><td><input type="text" placeholder="Owner" name="owner"></td></tr>
		<tr><td>  Choose Image: </td><td> <input type="file" name="fileToUpload" id="fileToUpload"></td></tr>
		<tr><td colspan="2"><input type="submit" value="Add Place" style="padding:10px 40px"></td></tr>								
                </table>
                </form>
	</div>
</div>

<div id="copyright" class="container">
	<p>&copy; Untitled. All rights reserved. | Photos by <a href="http://fotogrph.com/">Fotogrph</a> | Design by <a href="http://templated.co" rel="nofollow">TEMPLATED</a>.</p>
		<ul class="contact">
			<li><a href="#" class="icon icon-twitter"><span>Twitter</span></a></li>
			<li><a href="#" class="icon icon-facebook"><span></span></a></li>
			<li><a href="#" class="icon icon-dribbble"><span>Pinterest</span></a></li>
			<li><a href="#" class="icon icon-tumblr"><span>Google+</span></a></li>
			<li><a href="#" class="icon icon-rss"><span>Pinterest</span></a></li>
		</ul>
</div>
</body>
</html>