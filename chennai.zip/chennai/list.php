<?php 

include('connectioncode.php');
$sql="";
if(isset($_GET["from"]))
$sql="select * from places order by name   limit ".$_GET["from"].",".$_GET["to"]."";
else if(isset($_GET["pattern"]))
$sql="select * from places where name like '%".$_GET["pattern"]."%' order by name  ";
else
$sql="select * from places order by name   limit 0,10";

$result=mysql_query($sql,$con);

echo '[';


$i=0;
while($conn=mysql_fetch_array($result))
{
$sql1="select  avg(rating) from zrating".$conn["ratingtable"]."";
//$sql1="select 1.5";
$result1=mysql_query($sql1,$con);

$rating=mysql_result($result1,0,0);
if($rating=="")
$rating=0;

if($i==0)
echo '{
        "title": "'.$conn["name"].'",
        "image": "http://cchat.in/chennai/'.$conn["image"].'",
        "rating": '.$rating.',
        "releaseYear": 2014,
        "genre": ["'.$conn["ratingtable"].'","'.$conn["lon"].'","'.$conn["lat"].'","'.$conn["address"].'","'.$conn["image"].'"]
    }';
else
echo ',{
        "title": "'.$conn["name"].'",
        "image": "http://cchat.in/chennai/'.$conn["image"].'",
        "rating": '.$rating.',
        "releaseYear": 2010,
        "genre": ["'.$conn["ratingtable"].'","'.$conn["lon"].'","'.$conn["lat"].'","'.$conn["address"].'","'.$conn["image"].'"]
    }';
$i++;
}

echo ']';


?>