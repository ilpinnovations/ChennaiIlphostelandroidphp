<?php 
include('connectioncode.php');

function generateRandomString($length) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}


$sql="select * from places";
$result=mysql_query($sql,$con);


while($conn=mysql_fetch_array($result))
{

$code=generateRandomString(15);

$sql1="update places set ratingtable='".$code."' where sno='".$conn["sno"]."'";
$result1=mysql_query($sql1,$con);

$sql4="create table zrating".$code." (sno int primary key auto_increment,name varchar(20),employeeid varchar(20) unique key,comment varchar(1000),time varchar(20),rating int)";
mysql_query($sql4,$con);

}


 ?>