<?php 
include('connectioncode.php');

$sql="select * from zrating".$_GET["ratingtable"]."";

$result=mysql_query($sql,$con)or die(mysql_error());

echo '[';


$i=0;
while($conn=mysql_fetch_array($result))
{

if($i==0)
echo '{
        "title": "'.$conn["name"].'",
        "image": "http://cchat.in/chennai/'.$conn["image"].'",
        "rating": '.$conn["rating"].',
        "releaseYear": 2014,
        "genre": ["'.str_replace("xyzzyspoonshift1"," ",$conn["comment"]).'"]
    }';
else
echo ',{
        "title": "'.$conn["name"].'",
        "image": "http://cchat.in/chennai/'.$conn["image"].'",
        "rating": '.$conn["rating"].',
        "releaseYear": 2014,
        "genre": ["'.str_replace("xyzzyspoonshift1"," ",$conn["comment"]).'"]
    }';
$i++;
}

echo ']';

?>