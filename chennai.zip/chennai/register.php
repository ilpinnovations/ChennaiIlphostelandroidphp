<?php 

include('connectioncode.php');

$sql="insert into register values(null,'".$_GET["employee_id"]."','".str_replace("xyzzyspoonshift1"," ",$_GET["name"])."','".$_GET["location"]."','".$_GET["lg"]."','".$_GET["email"]."','".$_GET["imei"]."',now())";
mysql_query($sql,$con) or die(mysql_error());



?>