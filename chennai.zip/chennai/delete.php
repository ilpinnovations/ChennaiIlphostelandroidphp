<?php 

include('connectioncode.php');

$sql="delete from places where sno='".$_GET["sno"]."'";
$result=mysql_query($sql,$con);

header("Location:manage.php?data=Entry Deleted Sucessfully");

?>