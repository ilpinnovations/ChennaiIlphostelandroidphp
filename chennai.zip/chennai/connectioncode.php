                                <?php
	//session_start();
	$con=mysql_connect("localhost","cchatwsk_lokesh","vaio744001027");

$sql="USE cchatwsk_chennai";
mysql_query($sql,$con);
?>
                            